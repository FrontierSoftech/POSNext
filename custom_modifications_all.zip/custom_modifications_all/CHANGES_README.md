# Custom Modifications Branch - All Changes

## Overview

This package contains all files modified in the `custom-modifications` branch. The changes include GST tax handling, RCM tax filtering, tax-inclusive mode improvements, Finance Lender payments, GSTIN autofill, and UI enhancements.

## Branch Information

- **Branch:** `custom-modifications`
- **Latest Commit:** `16a5a93` - "Refactor tax handling: consolidate RCM filtering and tax-inclusive logic into utility functions"

## Files Changed

### Backend API Files (Python)

1. **`pos_next/api/__init__.py`**
   - Added imports for new modules (gst_tax, tax_utils)

2. **`pos_next/api/finance_lender.py`** (NEW)
   - Finance Lender payment handling

3. **`pos_next/api/gst_tax.py`** (NEW)
   - GST tax utilities for auto-detection of SGST+CGST vs IGST
   - Place of supply calculation
   - Inter-state vs intra-state detection

4. **`pos_next/api/gstin.py`** (NEW)
   - Custom GSTIN API endpoint for POS users without desk access
   - GSTIN verification and validation

5. **`pos_next/api/invoices.py`**
   - Tax-inclusive mode handling
   - RCM tax filtering
   - GST tax template auto-detection
   - Finance Lender payment integration
   - Refactored to use tax_utils

6. **`pos_next/api/items.py`**
   - Query Builder for Frappe 16 compatibility
   - Removed SQL function from filter field

7. **`pos_next/api/pos_profile.py`**
   - Enhanced tax configuration
   - Shipping address handling for GST

8. **`pos_next/api/sales_invoice_hooks.py`**
   - Tax-inclusive validation hooks
   - RCM tax filtering in validate and before_save hooks
   - Refactored to use tax_utils

9. **`pos_next/api/tax_utils.py`** (NEW)
   - Centralized utility functions for tax handling
   - `filter_rcm_taxes()` - RCM tax filtering
   - `ensure_taxes_loaded()` - Tax loading
   - `apply_tax_inclusive_settings()` - Tax-inclusive mode setup
   - `calculate_taxes_if_needed()` - Tax calculation

10. **`pos_next/hooks.py`**
    - Added before_save hook for Sales Invoice

### Frontend Files (Vue.js)

1. **`POS/src/components/sale/CreateCustomerDialog.vue`**
   - GSTIN autofill functionality
   - Enhanced customer fields (GST category, mobile with country code, email)
   - Improved UX and error handling

2. **`POS/src/components/sale/InvoiceCart.vue`**
   - Display "IGST" or "SGST + CGST" instead of generic "Tax" label
   - Dynamic tax label based on inter-state/intra-state

3. **`POS/src/components/sale/PaymentDialog.vue`**
   - Finance Lender payment integration
   - Enhanced payment handling

4. **`POS/src/composables/useInvoice.js`**
   - Tax rules and inter-state detection
   - Enhanced invoice state management

5. **`POS/src/pages/POSSale.vue`**
   - Various UI improvements and fixes

6. **`POS/src/stores/posCart.js`**
   - Added taxRules and isInterState to cart store
   - Enhanced cart state management

### Documentation

1. **`RCM_TAX_FIX.md`**
   - Documentation for RCM tax filtering fix

## Key Features Implemented

### 1. GST Tax Handling
- **Auto-detection:** Automatically detects SGST+CGST for intra-state and IGST for inter-state transactions
- **Place of Supply:** Uses customer shipping address to determine tax type
- **Tax Template Selection:** Auto-selects appropriate tax template based on customer location

### 2. Tax-Inclusive Mode
- **Tax Extraction:** Properly extracts tax from item rates in tax-inclusive mode
- **Multiple Safeguards:** validate() and before_save() hooks ensure taxes are calculated correctly
- **RCM Filtering:** Automatically filters out RCM taxes for normal sales transactions

### 3. RCM Tax Filtering
- **Automatic Filtering:** Removes RCM (Reverse Charge Mechanism) taxes when `is_reverse_charge` is not set
- **India Compliance Compatible:** Works with India Compliance app validation
- **Pattern Matching:** Uses both India Compliance API and pattern matching for RCM detection

### 4. Finance Lender Payments
- **Integration:** Support for Finance Lender payment modes
- **Custom Fields:** Stores Finance Lender payment details on invoice

### 5. GSTIN Autofill
- **Custom API:** GSTIN verification endpoint for POS users
- **Auto-population:** Automatically fills customer details from GSTIN
- **Error Handling:** Helpful error messages for verification failures

### 6. UI Improvements
- **Tax Labels:** Shows "IGST" or "SGST + CGST" instead of generic "Tax"
- **Customer Dialog:** Enhanced Create Customer form with GSTIN autofill
- **Better UX:** Improved error messages and user feedback

## Code Refactoring

### Tax Utilities Consolidation
- **Before:** ~400 lines of duplicated tax logic across 3 files
- **After:** ~176 lines in one utility file + ~30 lines of calls
- **Reduction:** ~50% code reduction (~200 lines removed)

### Benefits
1. No code duplication
2. Easier maintenance
3. Cleaner code
4. Less logging (only critical warnings/errors)
5. Same functionality preserved

## Testing Checklist

- [ ] Tax-inclusive mode invoices (SGST+CGST)
- [ ] Tax-inclusive mode invoices (IGST)
- [ ] RCM tax filtering (should not appear in normal invoices)
- [ ] Tax calculation accuracy
- [ ] Invoice submission
- [ ] Finance Lender payments
- [ ] GSTIN autofill
- [ ] Customer creation with GSTIN
- [ ] Inter-state vs intra-state detection
- [ ] Tax label display in UI

## Installation

1. Extract the zip file
2. Copy files to their respective locations in the `pos_next` app
3. Restart Frappe/ERPNext
4. Rebuild frontend assets: `cd POS && yarn build`

## Rollback

If issues occur, you can revert specific commits:
```bash
git revert <commit-hash>
```

Or revert the entire branch to a previous state.

## Commit History

Recent commits in this branch:
- `16a5a93` - Refactor tax handling: consolidate RCM filtering and tax-inclusive logic
- `4a68af9` - feat: GST auto-selection, Finance Lender payments, Tax inclusive improvements
- `1c96642` - feat: Display IGST or SGST+CGST instead of generic 'Tax' label in POS UI
- `e04ae11` - fix: Filter out RCM taxes for normal POS sales transactions
- `ae4ac61` - feat: Add GSTIN autofill and enhanced customer fields to Create Customer dialog

## Support

For issues or questions, refer to the individual commit messages or the documentation files included in this package.
